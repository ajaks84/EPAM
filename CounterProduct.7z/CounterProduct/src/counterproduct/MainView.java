package counterproduct;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;

public class MainView extends ViewPart {

	public static final String ID = "counterproduct.MainView";

	public MainView() {
	}

	@Override
	public void createPartControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION));

		Button btnLn_1 = new Button(container, SWT.NONE);
		btnLn_1.addSelectionListener(new SelectionListener() {

			private static final long serialVersionUID = -7849580001762016279L;

			public void widgetSelected(SelectionEvent event) {
				
				callView ("LN-01");
			}

			public void widgetDefaultSelected(SelectionEvent event) {

			}
		});
		btnLn_1.setBounds(41, 51, 104, 47);
		btnLn_1.setText("LN-01");
	

		Button btnLz_1 = new Button(container, SWT.NONE);
		btnLz_1.addSelectionListener(new SelectionListener() {

			private static final long serialVersionUID = -1888908818793039324L;

			public void widgetSelected(SelectionEvent event) {
				
				callView ("LZ-01");
			}

			public void widgetDefaultSelected(SelectionEvent event) {

			}
		});
		btnLz_1.setBounds(41, 134, 104, 47);
		btnLz_1.setText("LZ-01");

		Button btnPr_1 = new Button(container, SWT.NONE);
		btnPr_1.addSelectionListener(new SelectionListener() {

			private static final long serialVersionUID = -7849580001762016279L;

			public void widgetSelected(SelectionEvent event) {
				
				callView ("PR-01");
			}

			public void widgetDefaultSelected(SelectionEvent event) {

			}
		});
		btnPr_1.setBounds(41, 310, 104, 47);
		btnPr_1.setText("PR-01");

		Button btnLz_2 = new Button(container, SWT.NONE);
		btnLz_2.addSelectionListener(new SelectionListener() {

			private static final long serialVersionUID = -7849580001762016279L;

			public void widgetSelected(SelectionEvent event) {
				
				callView ("LZ-02");
			}

			public void widgetDefaultSelected(SelectionEvent event) {

			}
		});
		btnLz_2.setText("LZ-02");
		btnLz_2.setBounds(41, 221, 104, 47);

		Button btnPr_2 = new Button(container, SWT.NONE);
		btnPr_2.addSelectionListener(new SelectionListener() {

			private static final long serialVersionUID = -7849580001762016279L;

			public void widgetSelected(SelectionEvent event) {
				
				callView ("PR-02");
			}

			public void widgetDefaultSelected(SelectionEvent event) {

			}
		});
		btnPr_2.setText("PR-02");
		btnPr_2.setBounds(41, 398, 104, 47);

	}
	
	private void callView (String lineName){
		
		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
		
		try {
			   String viewIdToOpen = ShiftSelectView.ID;
			   ICommunicationView viewToOpen = (ICommunicationView) activePage.showView(viewIdToOpen);
			  
			viewToOpen.accept(lineName, null, null);
			
			viewToOpen.populate();
			} catch (PartInitException e) { }
		
		
		
		
		
	}

	@Override
	public void setFocus() {
		
	}


}
