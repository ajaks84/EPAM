package counterproduct;

import java.util.ArrayList;
import java.util.List;

public enum ModelProvider {
  INSTANCE;

  private List<TableEntry> tableEntry;

  private ModelProvider() {
    tableEntry = new ArrayList<TableEntry>();
    
    @SuppressWarnings("unused")
	MySQLAccess dao = new MySQLAccess();
    try {
		//dao.readDataBasePresentDay();
	} catch (Exception e) {
		e.printStackTrace();
	}
    
  }

  public List<TableEntry> getTableEntry() {
    return tableEntry;
  }

} 
