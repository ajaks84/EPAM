package counterproduct;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.swt.widgets.Table;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ColumnLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.swt.widgets.Button;

public class TableView extends ViewPart {

	public static final String ID = "counterproduct.TableViewPreviousDay"; //$NON-NLS-1$
	private Table table;
	TableViewer tableViewer;

	public TableView() {
	}

	/**
	 * Create contents of the view part.
	 * 
	 * @param parent
	 */
	@Override
	public void createPartControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION));

		Label lblShiftData = new Label(container, SWT.NONE);
		lblShiftData.setFont(SWTResourceManager.getFont("Segoe UI", 13, SWT.NORMAL));
		lblShiftData.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_DARK_SHADOW));
		lblShiftData.setBackground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION));
		lblShiftData.setBounds(232, 10, 89, 29);
		lblShiftData.setText("Shift Data");

		tableViewer = new TableViewer(container, SWT.BORDER | SWT.FULL_SELECTION);
		table = tableViewer.getTable();
		table.setBounds(46, 52, 504, 393);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		
		 

		TableViewerColumn tableViewerColumn_4 = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnNewColumn_4 = tableViewerColumn_4.getColumn();
		tblclmnNewColumn_4.setAlignment(SWT.CENTER);
		tblclmnNewColumn_4.setWidth(154);
		tblclmnNewColumn_4.setText("\u0420\u0443\u043A\u0430\u0432 \u2116");
		tableViewerColumn_4.setLabelProvider(new ColumnLabelProvider() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 3347076777759032737L;

			@Override
			public String getText(Object element) {
				TableEntry p = (TableEntry) element;
				return p.getVal_st_1();
			}
		});

		TableViewerColumn tableViewerColumn_3 = new TableViewerColumn(tableViewer, SWT.NONE);
		TableColumn tblclmnNewColumn_3 = tableViewerColumn_3.getColumn();
		tblclmnNewColumn_3.setAlignment(SWT.CENTER);
		tblclmnNewColumn_3.setWidth(178);
		tblclmnNewColumn_3.setText("\u041A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u043E");
		tableViewerColumn_3.setLabelProvider(new ColumnLabelProvider() {
			/**
			 * 
			 */
			private static final long serialVersionUID = -3661597573222868963L;

			@Override
			public String getText(Object element) {
				TableEntry p = (TableEntry) element;
				return p.getDateTime_st_1();
			}
		});
		
		TableViewerColumn tableViewerColumn = new
				  TableViewerColumn(tableViewer, SWT.NONE); TableColumn
				  tblclmnNewColumn = tableViewerColumn.getColumn();
 tblclmnNewColumn.setAlignment(SWT.CENTER);
				  tblclmnNewColumn.setWidth(168); tblclmnNewColumn.setText(
				  "\u0414\u0430\u0442\u0430, \u0432\u0440\u0435\u043C\u044F"); tableViewerColumn.setLabelProvider(new
				  ColumnLabelProvider() {
				  
				  /**
					 * 
					 */
					private static final long serialVersionUID = -5285074994157074737L;

				@Override public String getText(Object element) { 
					//TableEntry p = (TableEntry) element; 
				  return null;
						  //p.getDateTime_1(); 
				  
				} });
				  
				  
MySQLAccess dao = new MySQLAccess();

		Button btnRefresh = new Button(container, SWT.NONE);
		btnRefresh.setBounds(345, 10, 62, 25);
		btnRefresh.setText("Refresh");
		btnRefresh.addSelectionListener(new SelectionListener() {

			/**
			 * 
			 */
			private static final long serialVersionUID = 8990578218512426867L;

			public void widgetSelected(SelectionEvent event) {

				System.out.println("refresh");
				
				
				//  HERE is the INPUT!!!!!
				System.out.println("trying to read previous day data1");
				
try {System.out.println("trying to read previous day data2");
	tableViewer.setInput(dao.getResultSetForTableView());
	
	
} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
				//tableViewer.refresh(true);
				//tableViewer.getTable().getDisplay().update();
				/*
				 * try { PlatformUI.getWorkbench().getActiveWorkbenchWindow().
				 * getActivePage().showView(TableView.ID); } catch
				 * (PartInitException e) { // TODO Auto-generated catch block
				 * e.printStackTrace(); }
				 */
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub

			}
		});
		
		tableViewer.setContentProvider(ArrayContentProvider.getInstance());
		try {
			tableViewer.setInput(dao.getResultSetForTableView());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		createActions();
		initializeToolBar();
		initializeMenu();
	}
	
	public void refresh()
	{
	tableViewer.getTable().getDisplay().asyncExec(new Runnable()
	{
	public void run()
	{
	tableViewer.refresh();
	}
	});
	}

	/**
	 * Create the actions.
	 */
	private void createActions() {
		// Create the actions
	}

	/**
	 * Initialize the toolbar.
	 */
	private void initializeToolBar() {
	}

	/**
	 * Initialize the menu.
	 */
	private void initializeMenu() {
	}

	@Override
	public void setFocus() {
		// Set the focus
	}
}
