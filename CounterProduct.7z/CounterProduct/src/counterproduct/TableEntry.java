package counterproduct;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

public class TableEntry {
	private String marker_number;
	private String value_st_1;
	private String datetime_st1;
	private String value_st_2;
	private String datetime_st2;
	private String value_st_3;
	private String datetime_st3;
	private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);
	public TableEntry() {
	}

	public TableEntry(String marker_number, String value_st_1, String datetime_st1, String value_st_2, String datetime_st2, String value_st_3, String datetime_st3) {
		super();
		this.marker_number = marker_number;
		this.value_st_1 = value_st_1;
		this.datetime_st1 = datetime_st1;
		this.value_st_2 = value_st_2;
		this.datetime_st2 = datetime_st2;
		this.value_st_3 = value_st_3;
		this.datetime_st3 = datetime_st3;
	}

	public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener) {
		propertyChangeSupport.addPropertyChangeListener(propertyName, listener);
	}

	public void removePropertyChangeListener(PropertyChangeListener listener) {
		propertyChangeSupport.removePropertyChangeListener(listener);
	}

	
	public void setMarker_number(String marker_number) {
		propertyChangeSupport.firePropertyChange("marker_number",  this.marker_number, this.marker_number = marker_number);
	}
	
    public void setVal_st_1(String value) {
		propertyChangeSupport.firePropertyChange("lid_pcs_1", this.value_st_1, this.value_st_1 = value);
	}
    
	public void setDateTime_st_1(String datetime) {
		propertyChangeSupport.firePropertyChange("datetime_1", this.datetime_st1, this.datetime_st1 = datetime);
	}

	public void setVal_st_2(String value) {
		propertyChangeSupport.firePropertyChange("lid_pcs_2", this.value_st_2, this.value_st_2 = value);
	}
	
	public void setDateTime_st_2(String datetime) {
		propertyChangeSupport.firePropertyChange("datetime_2",  this.datetime_st2, this.datetime_st2 = datetime);
	}


	public void setVal_st_3(String value) {
		propertyChangeSupport.firePropertyChange("lid_pcs_3", this.value_st_3, this.value_st_3 = value);
	}
	
	public void setDateTime_st_3(String datetime) {
		propertyChangeSupport.firePropertyChange("datetime_3", this.datetime_st3, this.datetime_st3 = datetime);
	}
	
	
    public String getVal_st_1() {
		return value_st_1;
	}

	public String getDateTime_st_1() {
		return datetime_st1;
	}

	public String getVal_st_2() {
		return value_st_2;
	}

	public String getDateTime_st_2() {
		return datetime_st2;
	}
	
	public String getVal_st_3() {
		return value_st_3;
	}

	public String getDateTime_st_3() {
		return datetime_st3;
	}
	
	
	/*public String getDateTime_1() {
		String s = marker_number;
		String shortDate = s.substring(5, s.length()-2);
		return shortDate;
	}
	
	public String getDateTime_2() {
		String s = value_st_2;
		String shortDate = s.substring(5, s.length()-2);
		return shortDate;
	}

	public String getVal_2() {
		return value_st_3;
	}

	public String getCnlNum_2() {
		return datetime_st2;
	}
	
	public String getTab() {
		return datetime_st3;
	}
*/
	
	

}