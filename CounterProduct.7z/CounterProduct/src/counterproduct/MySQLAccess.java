package counterproduct;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
//import java.util.Date;
import java.util.List;


public class MySQLAccess {
	private Connection connect = null;
	private Statement statement = null;
	private ResultSet resultSet = null;
	private List<TableEntry> tableEntry;
	private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private Calendar cal = Calendar.getInstance();
    private String sQLQerryPattern = "yyyy-MM-dd" ;
   // private String lineName = null;
   // private String date = null;
    //private String shift = null;
    

	public  ResultSet getResultSet(String lineName, String date, String shift) throws Exception {
		
		
		if (lineName == "LZ-01"){
		
			try {
				
				String shift_val;
				
				if (shift =="I �����"){shift_val = "07:";} else {shift_val = "19:";}
				
				Class.forName("com.mysql.jdbc.Driver");
				
				connect = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "123");

				statement = connect.createStatement();
				
				resultSet = statement.executeQuery("SELECT Cnt_Table_11.*, Cnt_Table_12.*, Cnt_Table_13.* FROM Cnt_Table_11, Cnt_Table_12, Cnt_Table_13 WHERE Cnt_Table_11.marker_num_1 = Cnt_Table_12.marker_num_2 AND Cnt_Table_11.marker_num_1 = Cnt_Table_13.marker_num_3 AND datetime_1 like '%"+date+"%'AND datetime_1 like '%"+shift_val+"%'");
						
			} catch (Exception e) {
				throw e;
			} }else
				
			{
				
				/*Display display = new Display();
				Shell shell = new Shell(display);
				shell.open();
				
				MessageBox dialog =
				        new MessageBox(shell, SWT.ICON_QUESTION | SWT.OK| SWT.CANCEL);
				dialog.setText("My info");
				dialog.setMessage("Do you really want to do this?");

				// open dialog and await user selection
				int returnCode = dialog.open();*/
				
				
			}
			//finally {close();}
			return resultSet;
		
		

	}
	
	
	public List<TableEntry> getResultSetForTableView() throws Exception {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			connect = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "123");

			statement = connect.createStatement();
			
			cal.add(Calendar.DATE, -1);
			String str = dateFormat.format(cal.getTime());
			
			resultSet = statement.executeQuery("select * from test.cnt_table where datetime like '%"+str+" %'");		
			
		} catch (Exception e) {
			throw e;
		} 
		//finally {close();}
		return getTableEntry(resultSet);
		

	}

	private List<TableEntry> getTableEntry(ResultSet resultSet) throws SQLException {
		// ResultSet is initially before the first data set
		tableEntry = new ArrayList<TableEntry>();
		while (resultSet.next()) {
			System.out.println("tableEntry is empty?"+tableEntry.isEmpty());
			System.out.println(resultSet.getString("lid_pcs_1"));
			// It is possible to get the columns via name
			// also possible to get the columns via the column number
			// which starts at 1
			// e.g. resultSet.getSTring(2);
			TableEntry t = new TableEntry();
			t.setMarker_number(resultSet.getString("marker_num_1"));
			t.setVal_st_1(resultSet.getString("lid_pcs_1"));
			t.setDateTime_st_1(resultSet.getString("datetime_1"));
			t.setVal_st_2(resultSet.getString("lid_pcs_2"));
			t.setDateTime_st_2(resultSet.getString("datetime_2"));
			t.setVal_st_3(resultSet.getString("lid_pcs_3"));
			t.setDateTime_st_3(resultSet.getString("datetime_3"));

			tableEntry.add(t);

		}
		return tableEntry;
	}
	
	// You need to close the resultSet
	public void close() {
		try {
			if (resultSet != null) {
				resultSet.close();
			}

			if (statement != null) {
				statement.close();
			}

			if (connect != null) {
				connect.close();
			}
		} catch (Exception e) {

		}
	}
	
	
	@SuppressWarnings("unused")
	private String changeDatePattern(String date){
		
		dateFormat.applyPattern(sQLQerryPattern);
		
		return null;}

}