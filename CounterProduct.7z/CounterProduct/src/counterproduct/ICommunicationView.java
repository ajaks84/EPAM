package counterproduct;

import org.eclipse.ui.IViewPart;

public interface ICommunicationView extends IViewPart {
	
	public void accept(String lineName, String date, String shift);
	
	public void populate();
}