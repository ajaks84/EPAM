package counterproduct;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;

public class ShiftReportView extends ViewPart implements ICommunicationView {

	public static final String ID = "counterproduct.ShiftReportView";
	private ResultSet resultSet = null;
	private String lineName;
	private String date;
	private String shift;
	private Label lbl_shiftReportValue;
	private Label lbl_dateValue;
	private Label lbl_shiftValue;
	private Label lbl_inputValue;
	private Label lbl_outputValue_1;
	private Label lbl_outputValue_2;
	private Label lbl_tabValue;
	private Label lbl_epoxLaquerValue;
	private Label lbl_polyLaquerValue;
	private String tab;
	private String epox_laquer;
	private String poly_laquer;
	
	public ShiftReportView() {
	}

	@Override
	public void createPartControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setTouchEnabled(true);
		container.setEnabled(false);
		container.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));

		Label lbl_shiftReport = new Label(container, SWT.NONE);
		lbl_shiftReport.setAlignment(SWT.RIGHT);
		lbl_shiftReport.setFont(SWTResourceManager.getFont("Segoe UI", 14, SWT.BOLD));
		lbl_shiftReport.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_HIGHLIGHT_SHADOW));
		lbl_shiftReport.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_shiftReport.setBounds(69, 10, 173, 29);
		lbl_shiftReport.setText("\u0421\u043C\u0435\u043D\u043D\u044B\u0439 \u043E\u0442\u0447\u0435\u0442");
		
		lbl_shiftReportValue = new Label(container, SWT.NONE);
		lbl_shiftReportValue.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_HIGHLIGHT_SHADOW));
		lbl_shiftReportValue.setFont(SWTResourceManager.getFont("Segoe UI", 14, SWT.BOLD));
		lbl_shiftReportValue.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_shiftReportValue.setBounds(258, 10, 95, 29);
		
		Label lbl_date = new Label(container, SWT.NONE);
		lbl_date.setAlignment(SWT.RIGHT);
		lbl_date.setText("\u0414\u0430\u0442\u0430");
		lbl_date.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_HIGHLIGHT_SHADOW));
		lbl_date.setFont(SWTResourceManager.getFont("Segoe UI", 14, SWT.BOLD));
		lbl_date.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_date.setBounds(166, 45, 76, 29);
		
		lbl_dateValue = new Label(container, SWT.NONE);
		lbl_dateValue.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_HIGHLIGHT_SHADOW));
		lbl_dateValue.setFont(SWTResourceManager.getFont("Segoe UI", 14, SWT.BOLD));
		lbl_dateValue.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_dateValue.setBounds(258, 45, 139, 29);
		
		Label lbl_shift = new Label(container, SWT.NONE);
		lbl_shift.setAlignment(SWT.RIGHT);
		lbl_shift.setText("\u0421\u043C\u0435\u043D\u0430");
		lbl_shift.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_HIGHLIGHT_SHADOW));
		lbl_shift.setFont(SWTResourceManager.getFont("Segoe UI", 14, SWT.BOLD));
		lbl_shift.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_shift.setBounds(166, 80, 76, 29);
		
		lbl_shiftValue = new Label(container, SWT.NONE);
		lbl_shiftValue.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_HIGHLIGHT_SHADOW));
		lbl_shiftValue.setFont(SWTResourceManager.getFont("Segoe UI", 14, SWT.BOLD));
		lbl_shiftValue.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_shiftValue.setBounds(258, 80, 95, 29);
		
		Label lbl_input = new Label(container, SWT.NONE);
		lbl_input.setAlignment(SWT.RIGHT);
		lbl_input.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_input.setBounds(46, 163, 99, 15);
		lbl_input.setText("Input");
		
		lbl_inputValue = new Label(container, SWT.NONE);
		lbl_inputValue.setAlignment(SWT.RIGHT);
		lbl_inputValue.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_inputValue.setBounds(185, 163, 55, 15);
		
		Label lbl_pcs_1 = new Label(container, SWT.NONE);
		lbl_pcs_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_pcs_1.setText("pcs");
		lbl_pcs_1.setBounds(246, 163, 55, 29);
		
		Label lbl_output_1 = new Label(container, SWT.NONE);
		lbl_output_1.setAlignment(SWT.RIGHT);
		lbl_output_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_output_1.setText("Output_1");
		lbl_output_1.setBounds(46, 206, 99, 15);
		
		lbl_outputValue_1 = new Label(container, SWT.NONE);
		lbl_outputValue_1.setAlignment(SWT.RIGHT);
		lbl_outputValue_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_outputValue_1.setBounds(185, 206, 55, 15);
		
		Label lbl_pcs_2 = new Label(container, SWT.NONE);
		lbl_pcs_2.setText("pcs");
		lbl_pcs_2.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_pcs_2.setBounds(246, 206, 55, 29);
		
		lbl_outputValue_2 = new Label(container, SWT.NONE);
		lbl_outputValue_2.setAlignment(SWT.RIGHT);
		lbl_outputValue_2.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_outputValue_2.setBounds(187, 245, 55, 15);
		
		Label lbl_output_2 = new Label(container, SWT.NONE);
		lbl_output_2.setAlignment(SWT.RIGHT);
		lbl_output_2.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_output_2.setText("Output_2");
		lbl_output_2.setBounds(56, 245, 89, 15);
		
		Label lbl_pcs_3 = new Label(container, SWT.NONE);
		lbl_pcs_3.setText("pcs");
		lbl_pcs_3.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_pcs_3.setBounds(246, 245, 55, 29);
		
		Label lbl_tab = new Label(container, SWT.NONE);
		lbl_tab.setAlignment(SWT.RIGHT);
		lbl_tab.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_tab.setBounds(90, 292, 55, 15);
		lbl_tab.setText("TAB");
		
		lbl_tabValue = new Label(container, SWT.NONE);
		lbl_tabValue.setAlignment(SWT.RIGHT);
		lbl_tabValue.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_tabValue.setBounds(151, 292, 91, 15);
		lbl_tabValue.setText("\r\n");
		
		Label lbl_kg_1 = new Label(container, SWT.NONE);
		lbl_kg_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_kg_1.setText("kg");
		lbl_kg_1.setBounds(246, 292, 55, 29);
		
		Label lbl_epoxLaquer = new Label(container, SWT.NONE);
		lbl_epoxLaquer.setAlignment(SWT.RIGHT);
		lbl_epoxLaquer.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_epoxLaquer.setBounds(46, 327, 99, 29);
		lbl_epoxLaquer.setText("Epox Laquer");
		
		lbl_epoxLaquerValue = new Label(container, SWT.NONE);
		lbl_epoxLaquerValue.setAlignment(SWT.RIGHT);
		lbl_epoxLaquerValue.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_epoxLaquerValue.setText("\r\n");
		lbl_epoxLaquerValue.setBounds(151, 327, 89, 15);
		
		Label lbl_kg_2 = new Label(container, SWT.NONE);
		lbl_kg_2.setText("kg");
		lbl_kg_2.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_kg_2.setBounds(246, 327, 55, 29);
		
		Label lbl_polyLaquer = new Label(container, SWT.NONE);
		lbl_polyLaquer.setAlignment(SWT.RIGHT);
		lbl_polyLaquer.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_polyLaquer.setBounds(46, 362, 99, 29);
		lbl_polyLaquer.setText("Poly Laquer");
		
		lbl_polyLaquerValue = new Label(container, SWT.NONE);
		lbl_polyLaquerValue.setAlignment(SWT.RIGHT);
		lbl_polyLaquerValue.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_polyLaquerValue.setText("\r\n");
		lbl_polyLaquerValue.setBounds(151, 362, 89, 15);
		
		Label lbl_kg_3 = new Label(container, SWT.NONE);
		lbl_kg_3.setText("kg");
		lbl_kg_3.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_kg_3.setBounds(246, 362, 55, 29);


		createActions();
		initializeToolBar();
		initializeMenu();
	}

	
	private void createActions() {
	}

	private void initializeToolBar() {
	}

	private void initializeMenu() {
	}

	@Override
	public void setFocus() {
	}


	@Override
	public void accept(String lineName, String date, String shift) {
		
		this.lineName = lineName;
		
		try {
			Date date_1 = new SimpleDateFormat("dd.MM.yyyy").parse(date);
			String dateString2 = new SimpleDateFormat("yyyy-MM-dd").format(date_1);
			this.date = dateString2;
		    System.out.println(dateString2);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		this.shift = shift;
	}

	@Override
	public void populate() {
		
		lbl_shiftReportValue.setText(lineName);
		lbl_dateValue.setText(date);
		lbl_shiftValue.setText(shift);
		
		MySQLAccess dao = new MySQLAccess();

		try {
			resultSet = dao.getResultSet(lineName, date, shift);
			
			lbl_inputValue.setText("no data");
			lbl_outputValue_1.setText("no data");
			lbl_outputValue_2.setText("no data");
			
			lbl_tabValue.setText("no data");
			lbl_epoxLaquerValue.setText("no data");
			lbl_polyLaquerValue.setText("no data");
			
			tab = "no data";
			epox_laquer = "no data";
			poly_laquer = "no data";
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
if (resultSet!=null){
		try {
			while (resultSet.next()) {	
				lbl_inputValue.setText(resultSet.getString("lid_pcs_1"));
				lbl_outputValue_1.setText(resultSet.getString("lid_pcs_2"));
				lbl_outputValue_2.setText(resultSet.getString("lid_pcs_3"));
				tab = String.valueOf(Integer.parseInt(resultSet.getString("lid_pcs_2"))*0.0002478);
				epox_laquer = String.valueOf(Integer.parseInt(resultSet.getString("lid_pcs_3"))*0.000035);
				poly_laquer = String.valueOf(Integer.parseInt(resultSet.getString("lid_pcs_3"))*0.000034);
				lbl_tabValue.setText(tab.substring(0, Math.min(tab.length(), 4)));
				lbl_epoxLaquerValue.setText(epox_laquer.substring(0, Math.min(epox_laquer.length(), 4)));
				lbl_polyLaquerValue.setText(poly_laquer.substring(0, Math.min(poly_laquer.length(), 4)));
				System.out.println(tab);
				System.out.println(epox_laquer);
				System.out.println(poly_laquer);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	}	

		
	}

}
