package counterproduct;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.wb.swt.SWTResourceManager;

public class ShiftSelectView extends ViewPart implements ICommunicationView {

	public static final String ID = "counterproduct.ShiftSelectView"; 

	private SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
	private Calendar cal = Calendar.getInstance();
	private Label lbl_shiftName;
	private String lineName;
	private String presentDayDate = dateFormat.format(cal.getTime());
	private String previousDayDate;
	private DateTime calendar;
	private final String shiftVal_1 = "I �����";
	private final String shiftVal_2 = "II �����";
	
	public ShiftSelectView() {
	}

	@Override
	public void createPartControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setTouchEnabled(true);
		container.setFont(SWTResourceManager.getFont("Segoe UI", 20, SWT.NORMAL));
		container.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		
		lbl_shiftName = new Label(container, SWT.NONE);
		lbl_shiftName.setFont(SWTResourceManager.getFont("Segoe UI", 20, SWT.BOLD));
		lbl_shiftName.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		lbl_shiftName.setAlignment(SWT.CENTER);
		lbl_shiftName.setBounds(226, 10, 91, 34);
		
		
		{
			Button btnPresentDayShift = new Button(container, SWT.NONE);
			btnPresentDayShift.setBounds(54, 49, 180, 154);
			btnPresentDayShift.setText("\u0414\u043D\u0435\u0432\u043D\u0430\u044F \u0441\u043C\u0435\u043D\u0430\r\n\r\n"+ presentDayDate);
			btnPresentDayShift.addSelectionListener(new SelectionAdapter() {

				private static final long serialVersionUID = -756261034733805579L;

				public void widgetSelected(SelectionEvent event) {

					callView(lineName, presentDayDate, shiftVal_1);
				}

			});

			{
				Button btnPresentNightShift = new Button(container, SWT.NONE);
				btnPresentNightShift.setText("\u041D\u043E\u0447\u043D\u0430\u044F \u0441\u043C\u0435\u043D\u0430\r\n\r\n" + presentDayDate);
				btnPresentNightShift.setBounds(54, 257, 180, 154);
				btnPresentNightShift.addSelectionListener(new SelectionAdapter() {

					private static final long serialVersionUID = 1L;

					public void widgetSelected(SelectionEvent event) {
						
						callView(lineName, presentDayDate, shiftVal_2);
					}

				});

			}
			{   
				cal.add(Calendar.DATE, -1);
				previousDayDate = dateFormat.format(cal.getTime());
				
				Button btnPreviousDayShift = new Button(container, SWT.NONE);
				btnPreviousDayShift.setText("\u0414\u043D\u0435\u0432\u043D\u0430\u044F \u0441\u043C\u0435\u043D\u0430\r\n\r\n"+ previousDayDate);
				btnPreviousDayShift.setBounds(311, 49, 180, 154);
				btnPreviousDayShift.addSelectionListener(new SelectionAdapter() {

					private static final long serialVersionUID = -1684188945054068198L;

					public void widgetSelected(SelectionEvent event) {

						callView(lineName, previousDayDate, shiftVal_1);
						
					}

				});
			}
			{
				Button btnPreviousNightShift = new Button(container, SWT.NONE);
				btnPreviousNightShift.setText("\u041D\u043E\u0447\u043D\u0430\u044F \u0441\u043C\u0435\u043D\u0430\r\n\r\n"+ previousDayDate);
				btnPreviousNightShift.setBounds(311, 257, 180, 154);
				btnPreviousNightShift.addSelectionListener(new SelectionAdapter() {

					private static final long serialVersionUID = 3716179173350859025L;

					@Override
					public void widgetSelected(SelectionEvent e) {
						
						callView(lineName, previousDayDate, shiftVal_2);
					}
				});
			}

		}

		calendar = new DateTime(container, SWT.CALENDAR | SWT.SHORT);
		calendar.setTouchEnabled(true);
		calendar.setForeground(SWTResourceManager.getColor(SWT.COLOR_LIST_FOREGROUND));
		calendar.setBackground(SWTResourceManager.getColor(SWT.COLOR_TITLE_BACKGROUND_GRADIENT));
		calendar.setFont(SWTResourceManager.getFont("Segoe UI", 27, SWT.NORMAL));
		calendar.setBounds(165, 458, 206, 177);
		calendar.addSelectionListener(new SelectionAdapter() {

			private static final long serialVersionUID = -5610247528096520516L;

			public void widgetSelected(SelectionEvent event) {
				
				String pickDate = (calendar.getDay () + "."+ (calendar.getMonth () + 1)+ "." + calendar.getYear ());
				
				MyDialog dlg = new MyDialog(parent.getShell(), pickDate);
				
				int val = dlg.open();
				
				String shiftVal = null;
				
				if (val==0) { shiftVal = shiftVal_1;}
				
				if (val==1) { shiftVal = shiftVal_2;}
				
				if (shiftVal!= null && val!=-1){ callView(lineName, pickDate, shiftVal);}
			}
		
			});}

	private void callView(String lineName, String date, String shift) {
		
		System.out.println(lineName+" "+ date+" "+shift);

		IWorkbenchPage activePage = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();

		try {
			String viewIdToOpen = ShiftReportView.ID;
			ICommunicationView viewToOpen = (ICommunicationView) activePage.showView(viewIdToOpen);

			viewToOpen.accept(lineName, date, shift);

			viewToOpen.populate();
		} catch (PartInitException e) {

		}

	}

	@Override
	public void setFocus() {
	}

	@Override
	public void accept(String lineName, String date, String shift) {
		this.lineName = lineName;
	}

	@Override
	public void populate() {
		lbl_shiftName.setText(lineName);
	}
}
